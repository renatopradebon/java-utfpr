package br.com.ejb.soma.sessionbeans;

public interface Soma {
	
	public double soma(double numero1, double numero2);
}
