Atividade 5
Faça um programa que, utilizando o conceito de MulticastSocket, envie uma piada para um grupo de usuários.

Esse programa deverá seguir a mesma lógico do programa de Bate Papo feito em aula. Os usuários entram com o IP Multicast e a porta.

Extra (não é obrigatório): Para os alunos que quiserem, poderão tentar relacionar serviços diferentes às portas diferentes. Nesse caso, o mesmo endereço IP de Multicast seria utilizado pelos usuários, mas o número da porta indicaria um tipo de serviço diferente. Por exemplo, a porta 2000 envia piadas, a porta 3000 verifica o CPF, a porta 4000 transforma as escritas em maiusculas, e assim por diante.
