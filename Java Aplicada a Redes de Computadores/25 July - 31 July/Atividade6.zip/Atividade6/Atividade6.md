Atividade 6
CETEJ33 - Java Aplicada a Redes de Computadores - Java XIII23:55 PM
Crie um servidor Java RMI capaz de oferecer um método para validação de CPF.

Assim, o cliente ao se conectar ao servidor RMI, poderá invocar o método de validação passando um CPF como parâmetro.

Obs: Outra sugestão (não obrigatória) é o cliente enviar como pedido uma quantidade de CPFs válidos ao servidor.
