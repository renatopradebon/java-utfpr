Atividade 4
Crie um servidor de piadas em que o cliente ao se conectar recebe uma piada a cada conexão realizada no servidor.

Observações:
- crie um arquivo texto chamado: piadas.txt;
- cada piada deverá estar em uma linha do arquivo;
- crie um método para que retorne uma linha do arquivo cada vez que invocado;
- quando todas as piadas forem exibidas, retorne a mensagem: “Sem mais piadas para enviar”.
