package br.com.modelo.interfaces;

public interface BaseEntity {

	public Integer getId();

}