EXERCÍCIO 3: Envio de parâmetros
Utilize o mesmo banco de dados com a tabela de cidades e implemente duas Servlets:

A primeira Servlet (chamada FormBusca) deve imprimir um código HTML com um formulário que envie uma requisição HTTP enviando um parâmetro de nome “query” a outra Servlet.
A segunda Servlet (chamada ResultadosBusca) deve utilizar o parâmetro chamado “query” para realizar uma busca no banco de dados por cidades que comecem com o parâmetro “query”.
Para submeter o exercício no Moodle, limpe seu projeto no Netbeans, sem construi-lo novamente. Depois comprima a pasta do projeto e envie ao Moodle. Isso evita que sejam enviadas bibliotecas externas e códigos compilados.