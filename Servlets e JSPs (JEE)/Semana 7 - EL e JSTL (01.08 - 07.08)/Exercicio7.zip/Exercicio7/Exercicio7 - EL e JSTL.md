EXERCÍCIO 7: EL e JSTL
Utilizem o conceito de EL e JSTL na implementação do EXERCÍCIO 6: MVC.
